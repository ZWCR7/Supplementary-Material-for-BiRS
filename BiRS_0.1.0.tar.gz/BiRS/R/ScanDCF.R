#' The \code{SigScanDCF}: function for scan test obtain with a DCF Test
#' @param X: sample matrix
#' @param Y: sample matrix for second population, alternatively
#' @param foldlen: The length be splitted, default 4096, if dimension of X or Y less than 4096, suggest the dimension of X
#' @param Lmin: The smallest length of signal regions, default 40
#' @param Lmax: The largest length of signal regions, default 200
#' @param skip: The skip of different length of signal regions, default 1
#' @param MB: multiplier bootstrap size, default 1000
#' @param alpha: the size of test, default 0.05
#' @param COMPU: the type for computing p value, c('None', 'Region', 'Point'), default 'None' for not computing; 'Region' for computing
#' region based p value and 'Point' for point based p value.
#' @param Pvm: the type of p value, c('Emp', 'Asy'), default 'Emp' for empirical p value, alternative 'Asy' for asymptotic p value 
#' (only for point based p value)
#' @return \code{BSDCF_res}: the detection results, which include the specific signal region and the corresponding statistics and p-value 
SigScanDCF = function(X, Y = NULL, foldlen = 4096, Lmin = 40, Lmax = 200, skip = 1, MB = 1000, alpha = 0.05, Deal = 'Overlap', COMPU = 'None', Pvm = 'Asy')
{
  p = ncol(X); Signal = rep(0, p)
  split = ceiling(p/foldlen)
  
  S.split = list()
  
  if (split == 1)
  {
    S.split = c(S.split, list(1:p))
  }
  if (split != 1)
  {
    for (i in 1:(split - 1))
    {
      S.split = c(S.split, list(((i-1)*foldlen+1):(i*foldlen)))
    }
    S.split = c(S.split, list(((split-1)*foldlen+1):p))
  }
  
  if (is.null(Y))
  {
    totalre = XFTest(X, Y = NULL, MB, alpha)
  }
  else
  {
    totalre = XFTest(X, Y, MB, alpha)
  }
  
  bmax_prm = totalre$bound
  UnVec = totalre$UnVec
  rm(totalre)
  
  if ((COMPU == 'Point') && (Pvm == 'Asy')) UFC = UnVec
  
  Unprm = rep(0, split)
  for (sp in 1:split)
  {
    Unprm[sp] = max(UnVec[S.split[[sp]]])
  }
  
  reject_ind = rep(0, split)
  Slist = list()
  for (sp in 1:split)
  {
    if (Unprm[sp] > bmax_prm) 
    {
      reject_ind[sp] = 1
      Slist = c(Slist, list(S.split[[sp]]))
    }
  }
  
  if (sum(reject_ind) == 0) return("there is no evidence that there exist signal region")
  
  search_ind = seq(Lmin, Lmax, by = skip)
  Scanlist = list()
  for (sp in 1:split)
  {
    SubSeq = S.split[[sp]]
    pi = length(SubSeq)
    for (l in search_ind)
    {
      for (i in 1:(pi - l + 1))
      {
        Scanlist = c(Scanlist, list(SubSeq[i:(i + l - 1)]))
      }
    }
  }
  
  
  SigRegList = list()
  
  SL = length(Scanlist)
  UnV = rep(0, SL)
  
  for (j in 1:SL)
  {
    UnV[j] = max(UnVec[Scanlist[[j]]])
  }
  
  bmax = bmax_prm
  
  rm(UnVec)
  gc()
  
  while (length(Scanlist) != 0) 
  {
    
    Siglist = list()
    
    Un = NULL; rej.ind = NULL
    for (s in 1:SL)
    {
      if (UnV[s] > bmax)
      {
        Un = c(Un, UnV[s])
        Siglist = c(Siglist, list(Scanlist[[s]]))
        rej.ind = c(rej.ind, s)
      }
    }
    
    if (is.null(Un)) break
    Unmax = max(Un); max.ind = rej.ind[which.max(Un)]
    UnV1 = UnV[rej.ind]
    
    if (Deal == 'Overlap')
    {
      rmv = NULL
      for (j in 1:length(max.ind))
      {
        SigRegList = c(SigRegList, list(Scanlist[[max.ind[j]]]))
        rmv = c(rmv, Scanlist[[max.ind[j]]])
      }
    }
    
    if (Deal == 'Shortest')
    {
      len_rej = rep(0, length(max.ind))
      for (j in 1:length(max.ind))
      {
        len_rej[j] = length(Scanlist[[max.ind[j]]])
      }
      
      max.shortest.ind = max.ind[which.min(len_rej)]
      
      rmv = NULL
      for (j1 in 1:length(max.shortest.ind))
      {
        SigRegList = c(SigRegList, list(Scanlist[[max.shortest.ind[j1]]]))
        rmv = c(rmv, Scanlist[[max.shortest.ind[j1]]])
      }
    }
    
    
    Scanlist = list()
    UnV = NULL
    
    for (k in 1:length(Siglist))
    {
      set = Siglist[[k]]
      cup = 0
      for (t in 1:length(set))
      {
        if (sum(rmv == set[t]) != 0) cup = cup + 1
      }
      
      if (cup == 0)
      {
        Scanlist = c(Scanlist, list(set))
        UnV = c(UnV, UnV1[k])
      }
    }
    
    SL = length(Scanlist)
  }
  
  
  if (length(SigRegList) != 0)
  {
    for (i in 1:length(SigRegList))
    {
      Signal[SigRegList[[i]]] = 1
    }
  }
  
  indF = which(Signal == 1)
  nF = length(indF)
  startind = indF[1]; endind = NULL
  for (i in 1:(nF - 1))
  {
    if ((indF[i + 1] - indF[i]) > 1)
    {
      endind = c(endind, indF[i])
      startind = c(startind, indF[i + 1])
    }
  }
  endind = c(endind, indF[nF])
  
  Stat = rep(0, length(startind))
  Pv = rep(1, length(startind))
  
  PvPoint = rep(1, nF)
  StPoint = rep(0, nF)
  
  if (COMPU == 'Region')
  {
    if (is.null(Y))
    {
      for (j in 1:length(startind))
      {
        resj = XFTest(as.matrix(X[, startind[j]:endind[j]]), Y = NULL, MB, alpha)
        Stat[j] = resj$Un
        
        if (Pvm == 'Emp') Pv[j] = resj$Pvalue
      }
    }
    if (!is.null(Y))
    {
      for (j in 1:length(startind))
      {
        resj = XFTest(as.matrix(X[, startind[j]:endind[j]]), as.matrix(Y[, startind[j]:endind[j]]), MB, alpha)
        Stat[j] = resj$Un
        
        if (Pvm == 'Emp') Pv[j] = resj$Pvalue
      }
    }
  }
  
  if (COMPU == 'Point')
  {
    if (Pvm == 'Emp')
    {
      if (is.null(Y))
      {
        for (j in 1:nF)
        {
          resj = XFTest(as.matrix(X[ ,indF[j]]), Y = NULL, MB, alpha)
          StPoint[j] = resj$Un; PvPoint[j] = resj$Pvalue
        }
      }
      if (!is.null(Y))
      {
        for (j in 1:nF)
        {
          resj = XFTest(as.matrix(X[ ,indF[j]]), as.matrix(Y[ ,indF[j]]), MB, alpha)
          StPoint[j] = resj$Un; PvPoint[j] = resj$Pvalue
        }
      }
    }
    
    if (Pvm == 'Asy')
    {
      if (is.null(Y))
      {
        for (j in 1:nF)
        {
          StPoint[j] = UFC[indF[j]]
          PvPoint[j] = pnorm(UFC[indF[j]], 0, sqrt(sd(X[ ,indF[j]])^2), lower.tail = F)
        }
      }
      if (!is.null(Y))
      {
        for (j in 1:nF)
        {
          n = nrow(X); m = nrow(Y)
          StPoint[j] = UFC[indF[j]]
          PvPoint[j] = pnorm(UFC[indF[j]], 0, sqrt(sd(X[ ,indF[j]])^2 + n/m*sd(Y[ ,indF[j]])^2), lower.tail = F)
        }
      }
    }
  }
  
  
  BSDCF_res = data.frame(startind, endind, Stat, Pv)
  return(list(BSDCF_res = BSDCF_res, StPoint = StPoint, PvPoint = PvPoint, COMPU = COMPU))
}
