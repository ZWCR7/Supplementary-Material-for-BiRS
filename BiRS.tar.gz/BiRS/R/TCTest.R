#' The \code{CLTest}: High dimensional two sample mean test in Tony Cai.
#' @param X, Y: sample matrices
#' @param alpha: the size of test, default 0.05
#' @return \code{MIMat}: The vector of MI
#' @return \code{MI}: The test statistics
#' @return \code{reject}: Whether the test reject the null hypothesis
#' @return \code{Pvalue}: The p-value for the test
CLTest = function(X, Y, alpha = 0.05)
{
  n = nrow(X); m = nrow(Y); p = ncol(X)
  
  Zhat = colMeans(X) - colMeans(Y)
  
  OmegaD = (n - 1)/(n + m)*apply(X, 2, var) + (m - 1)/(n + m)*apply(Y, 2, var)
  
  MIMat = m*n/(m + n)*Zhat^2/OmegaD 
  
  MI = max(MIMat) - 2*log(p) + log(log(p))
  Pvalue = 1 - exp(-1/sqrt(pi)*exp(-MI/2))
  bound = -log(pi*log(1/(1 - alpha))^2) + 2*log(p) - log(log(p)) 
  
  reject = (Pvalue < alpha)
  
  return(list(MIMat = MIMat, MI = MI, bound = bound, reject = reject, Pvalue = Pvalue))
}
#####################################################################################################
