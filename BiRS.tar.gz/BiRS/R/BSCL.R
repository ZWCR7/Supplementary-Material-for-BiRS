#' The \code{BiSearchCL}: function for binary search for signal region
#' @param UnVec: Vector of CL statistics
#' @param Slist: alternative signal regions for binary search
#' @param trunc: The truncation parameter for the smallest signal region
#' @param alpha: the size of test, default 0.05
#' @return \code{Signal}: the p-vector indicates the signal region

BiSearchCL = function(UnVec, Slist, Signal, trunc = 3, alpha = 0.05)
{
  while(length(Slist) != 0)
  {
    Slist1 = list()
    l = length(Slist)
    
    UnV = rep(0, l); RG = NULL
    for (i in 1:l)
    {
      UnV[i] = max(UnVec[Slist[[i]]])
      RG = c(RG, Slist[[i]])
    }
    
    pR = length(RG)
    bmax = -log(pi*log(1/(1 - alpha))^2) + 2*log(pR) - log(log(pR))
    
    for (i in 1:l)
    {
      pi = length(Slist[[i]]); mi = ceiling(pi/2)
      initi = (UnV[i] > bmax)
      
      if (initi == 1 && pi > 2^trunc)
      {
        Slist1 = c(Slist1, list(Slist[[i]][1:mi]))
        Slist1 = c(Slist1, list(Slist[[i]][(mi + 1):pi]))
      }
      
      if (initi == 1 && pi <= 2^trunc)
      {
        index = Slist[[i]]
        Signal[index] = 1
      }
    }
    
    Slist = Slist1
  }
  
  return(Signal)
}