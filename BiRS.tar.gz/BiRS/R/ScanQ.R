#' The \code{SigScanQ}: function for scan test obtain with a Q-SCAN Test
#' @param X: sample matrix
#' @param Y: sample matrix
#' @param COV: related covariance matrix, suggest sample matrix
#' @Lmax: The largest length of signal regions, default 200
#' @Lmin: The smallest length of signal regions, default 40
#' @foldlen: The length be splitted, default 4096, if dimension of X or Y less than 4096, suggest the dimension of X
#' @steplength: The skip of different length of signal regions, default 1
#' @param MB: multiplier bootstrap size, default 1000
#' @param alpha: the size of test, default 0.05 
#' @param f: an overlap fraction, which controls for the overlapping proportion of of detected regions. For example,
#' when f=0, the detected regions are non-overlapped with each other,
#' and when f=1, we keep every susceptive region as detected regions. (Default is 0.)
#' @return \code{scan_res}: the results of Qscan procedure
SigScanQ = function(X, Y = NULL, COV, Lmax = 200, Lmin = 40, foldlen = 4096, steplength = 1, MB = 2000, alpha = 0.05, f = 0)
{
  if (is.null(Y))
  {
    scan_res = Q_SCAN(X, Y = NULL, COV, Lmax, Lmin, foldlen, steplength, MB, alpha, f)
    
    return(scan_res)
  }
  else
  {
    scan_res = Q_SCAN(X, Y, COV, Lmax, Lmin, foldlen, steplength, MB, alpha, f)
    
    return(scan_res)
  }
  
}