// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List TwoSamTest(arma::mat X, arma::mat Y, const int MB)
{
  int n = X.n_rows;
  int m = Y.n_rows;
  int p = X.n_cols;
  
  arma::mat Xbar;
  arma::mat Ybar;
  Xbar.zeros(1,p);
  Ybar.zeros(1,p);
  Xbar = mean(X,0);
  Ybar = mean(Y,0);
  
  arma::mat interX;
  arma::mat interY;
  interX.ones(n,1);
  interY.ones(m,1);
  
  Rcpp::Environment base_env("package:base");
  Rcpp::Function set_seed_r = base_env["set.seed"];
  set_seed_r(413);
  
  // ee = arma::randn<arma::mat>(MB,n+m);
  // arma::mat eeX;
  // arma::mat eeY;
  // 
  // eeX = ee.cols(0,n-1);
  // eeY = ee.cols(n,n+m-1);
  
  arma::mat SnMax;
  SnMax.zeros(MB,p);
  SnMax = abs((arma::randn<arma::mat>(MB,n))*(X - interX*Xbar)/sqrt(n) - 
    sqrt(n)/sqrt(m)*(arma::randn<arma::mat>(MB,m))*(Y - interY*Ybar)/sqrt(m));
  
  arma::mat UnV;
  UnV.zeros(1,p);
  UnV = sqrt(n)*abs(Xbar - Ybar);
  
  return List::create(Named("SneX") = SnMax, Named("UnV") = UnV);
}
