#include <RcppArmadillo.h>
#include <Rcpp.h>

// [[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;

// declare maxL2
arma::vec maxGe(int p, int Lmax, int Lmin, int skip, arma::mat u, arma::mat Cov, int times);

// [[Rcpp::export]]
arma::vec Q_SCAN_Thres(arma::mat Cov, int p, int times, int Lmax, int Lmin, int skip) {
  
  // initial value of threshold
  arma::vec thr;
  thr.zeros(times);
  
  // pesudo-score
  arma::mat ee;
  Rcpp::Environment base_env("package:base");
  Rcpp::Function set_seed_r = base_env["set.seed"];
  set_seed_r(2);
  ee = arma::randn<arma::mat>(times, p);
  
  arma::vec eigval;
  arma::mat eigvec;
  
  eig_sym(eigval, eigvec, Cov);
  
  int r;
  for (r = 0; r < p; r++)
  {
    if (eigval(r) < 0)
    {
      eigval(r) = 0;
    }
  }
  
  arma::mat D = sqrt(diagmat(eigval));
  arma::mat sqrtCOV = eigvec*D*trans(eigvec);
  
  arma::mat u;
  u = ee*sqrtCOV;
  
  
  thr = maxGe(p, Lmax, Lmin, skip, trans(u), Cov, times);
  
  return thr;
  
}



