// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List M_Search_Two(arma::mat X, arma::mat Y, const double threshold, const int Lmax, const int Lmin, const int skip, const int begid, const double f)
{
  int ij, i, j, k, ii, jj, kk;
  int num = 0;
  double sum0 = 0.0;
  double w1 = 0.0;
  double w2 = 0.0;
  double c1 = 0.0;
  double c2 = 0.0;
  double sumx = 0.0;
  
  int n = X.n_rows;
  int m = Y.n_rows;
  
  arma::rowvec x = (mean(X, 0) - mean(Y, 0))/sqrt(1.0/n + 1.0/m);
  
  arma::mat candidate(1, 4);
  candidate.zeros();
  
  double summax = -100000.0;
  arma::mat candidatemax(1,4);
  candidatemax.zeros();
  
  int p = X.n_cols;
  
  int lengthnum = (Lmax-Lmin)/skip + 1;
  
  for (ij = 0; ij < lengthnum; ij++)
  {
    i = Lmin + ij*skip;
    
    sum0 = 0;
    
    for (k = 0; k < i; k++)
    {
      sum0 = sum0 + x(k);
    }
    
    sumx = sum0/sqrt(i);
    
    if (sumx>threshold)
    {
      num = num + 1;
      candidate.resize(num, 4);
      candidate(num - 1, 0) = sumx;
      candidate(num - 1, 1) = 1;
      candidate(num - 1, 2) = i;
    }
    
    if(sumx>summax)
    {
      summax=sumx;
      candidatemax(0,0)=sumx;
      candidatemax(0,1)=1+begid-1;
      candidatemax(0,2)=i+begid-1;
    }
    
    
    for (j = 1; j < (p - i + 1); j++)
    {
      sum0 = sum0 - x(j - 1) + x(j + i - 1);
      
      sumx = sum0/sqrt(i);
      
      
      if (sumx>threshold)
      {
        num = num + 1;
        candidate.resize(num, 4);
        candidate(num - 1, 0) = sumx;
        candidate(num - 1, 1) = j + 1;
        candidate(num - 1, 2) = j + i;
      }
      
      if(sumx>summax)
      {
        summax=sumx;
        candidatemax(0,0)=sumx;
        candidatemax(0,1)=j + 1 + begid - 1;
        candidatemax(0,2)=j + i + begid - 1;
      }
    }
  }
  
  arma::uvec indices = sort_index(-candidate.col(0));
  candidate = candidate.rows(indices);
  
  double loc_left = 0;
  double loc_right = 0;
  
  for (ii = 0; ii < (num-1); ii++)
  {
    if (candidate(ii,3) < 1)
    {
      for (jj = ii + 1; jj < num; jj++)
      {
        if(candidate(ii, 1) < candidate(jj, 1))
        {
          loc_left = candidate(jj, 1);
        }else
        {
          loc_left = candidate(ii, 1);
        }
        if(candidate(ii, 2) < candidate(jj, 2))
        {
          loc_right = candidate(ii, 2);
        }else
        {
          loc_right = candidate(jj, 2);
        }
        
        if (loc_right > loc_left - 1)
        {
          if((loc_right-loc_left + 1)/(candidate(jj,2) - candidate(jj,1) + 1) > f)
          {
            candidate(jj, 3) = 1;
          }
          
          
        }
      }
    }
  }
  
  int num1 = 0;
  arma::mat res(1, 4);
  res.zeros();
  for (kk = 0; kk<num; kk++)
  {
    if (candidate(kk, 3)<1)
    {
      num1 = num1 + 1;
      res.resize(num1, 4);
      res(num1 - 1, 0) = candidate(kk, 0);
      res(num1 - 1, 1) = candidate(kk, 1) + begid - 1;
      res(num1 - 1, 2) = candidate(kk, 2) + begid - 1;
    }
  }
  return List::create(Named("res") = res, Named("resmost") = candidatemax);
}

