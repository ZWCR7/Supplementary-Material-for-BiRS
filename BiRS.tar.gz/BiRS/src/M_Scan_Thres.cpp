#include <RcppArmadillo.h>
#include <Rcpp.h>

// [[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;

// declare maxL2
arma::vec maxMe(int p, int Lmax, int Lmin, int skip, arma::mat u, int times);

// [[Rcpp::export]]
arma::vec M_SCAN_Thres(int p, int times, int Lmax, int Lmin, int skip) {
  
  // initial value of threshold
  arma::vec thr;
  thr.zeros(times);
  
  // pesudo-score
  arma::mat u;
  Rcpp::Environment base_env("package:base");
  Rcpp::Function set_seed_r = base_env["set.seed"];
  set_seed_r(413);
  u = arma::randn<arma::mat>(times, p);
  
  
  thr = maxMe(p, Lmax, Lmin, skip, trans(u), times);
  
  return thr;
  
}




