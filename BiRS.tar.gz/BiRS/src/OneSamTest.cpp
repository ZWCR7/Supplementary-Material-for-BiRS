// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List OneSamTest(arma::mat X, const int MB)
{
  int n = X.n_rows;
  int p = X.n_cols;
  
  arma::mat Xbar;
  Xbar.zeros(1,p);
  Xbar = mean(X,0);

  arma::mat inter;
  inter.ones(n,1);
  
  Rcpp::Environment base_env("package:base");
  Rcpp::Function set_seed_r = base_env["set.seed"];
  set_seed_r(413);
  
  arma::mat XmbMat;
  XmbMat.zeros(n,p);

  arma::mat SnMax;
  SnMax.zeros(MB,p);
  SnMax = abs((arma::randn<arma::mat>(MB,n))*(X - inter*Xbar)/sqrt(n));

  arma::mat UnV;
  UnV.zeros(1,p);
  UnV = abs(sqrt(n)*Xbar);
   
  return List::create(Named("SneX") = SnMax, Named("UnV") = UnV);
}
